
export const DEFAULT_MODAL_ANCHOR = document.body
export const SIZE_LARGE = 10 * 1024 * 1024 // 10 MB
export const MAX_PREVIEW_CHARACTERS = 20000
export const PREVIEW_HISTORY_LIMIT = 2 * 1024 * 1024 * 1024 // 2 GB
